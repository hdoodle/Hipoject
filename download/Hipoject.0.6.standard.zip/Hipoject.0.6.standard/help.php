<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<?php
include 'config.php';
?>
<title><?php echo "".$websitename.""?>&nbsp;-Powered By hehaoyuan1997</title>
<meta name="keywords" content="Hipoject,hehaoyuan1997">
<meta name="descrption" content="Hipoject��һ��ͼ������hehaoyuan1997��д">
<meta http-equiv="Content-Type" content="text/html; charset=GB2312" />
<meta name="author"
content="hehaoyuan1997">
<!---copyright (c) 2013-2013 hehaoyuan1997 All Rights Reserved--->
<!---Powered By hehaoyuan1997--->
<!---author website:http://www.ddpool.com/--->
<!---hehaoyuan1997��ʼ��2013��8��18��23:19:57��д--->
<style type="text/css">
div#container
{
   width: 960px;
   position: relative;
   margin-top: 0px;
   margin-left: auto;
   margin-right: auto;
   text-align: left;
}
body
{
   text-align: center;
   margin: 0;
   background-color: #E2E1E2;
   color: #000000;
}
</style>
<style type="text/css">
a
{
   color: #0000FF;
   text-decoration: underline;
}
a:visited
{
   color: #800080;
}
a:active
{
   color: #FF0000;
}
a:hover
{
   color: #0000FF;
   text-decoration: underline;
}
</style>
<style type="text/css">
#Layer1
{
   background-color: #2B7AFA;
}
#wb_Text1 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text1 div
{
   text-align: left;
}
#Layer3
{
   background-color: #2B7AFA;
}
#wb_Text4 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text4 div
{
   text-align: left;
}
#wb_Text3 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text3 div
{
   text-align: left;
}
#wb_Text6 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text6 div
{
   text-align: left;
}
#Layer2
{
   background-color: #D3D3D3;
}
#wb_Text5 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text5 div
{
   text-align: left;
}
#wb_CssMenu1
{
   border: 0px #2B7AFA solid;
   background-color: transparent;
}
#wb_CssMenu1 ul
{
   list-style-type: none;
   margin: 0;
   padding: 0;
}
#wb_CssMenu1 li
{
   float: left;
   margin: 0;
   padding: 0px 0px 0px 0px;
   width: 100px;
}
#wb_CssMenu1 a
{
   display: block;
   float: left;
   color: #FFFFFF;
   border: 0px #C0C0C0 solid;
   background-color: #2B7AFA;
   background-image: none;
   font-family: "SimHei";
   font-size: 20px;
   font-weight: normal;
   font-style: normal;
   text-decoration: none;
   width: 90px;
   height: 40px;
   padding: 0px 5px 0px 5px;
   vertical-align: middle;
   line-height: 40px;
   text-align: center;
}
#wb_CssMenu1 li:hover a, #wb_CssMenu1 a:hover
{
   color: #2B7AFA;
   background-color: #FFFFFF;
   background-image: none;
   border: 0px #FFFFFF solid;
}
#wb_CssMenu1 li.firstmain
{
   padding-left: 0px;
}
#wb_CssMenu1 li.lastmain
{
   padding-right: 0px;
}
#wb_CssMenu1 br
{
   clear: both;
   font-size: 1px;
   height: 0;
   line-height: 0px;
}
#wb_Text1000 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text1000 div
{
   text-align: left;
}
</style>
</head>
<body>
<div id="container">
<div id="Layer1" style="position:absolute;text-align:left;left:0px;top:0px;width:960px;height:40px;z-index:5;" title="">
<h1><div id="h1" style="position:absolute;left:10px;top:4px;width:316px;height:29px;z-index:0;text-align:left;font-weight��normal;"><span style="color:#FFFFFF;font-family:Arial;font-size:24px;"><?php echo "".$websitename."&nbsp".$version."" ?></span></div></h1>
</div>
<div id="Layer3" style="position:absolute;text-align:left;left:0px;top:400px;width:960px;height:100px;z-index:6;" title="">
<div id="wb_Text4" style="position:absolute;left:10px;top:50px;width:960px;height:20px;z-index:4;text-align:left;">
<span style="color:#FFFFFF;font-family:����;font-size:16px;"><!---ʱ����ʾ����---><?php
    echo date("������Y��m��d��Hʱi��s��(��ʱ��ʱ��ΪeP)");
    echo "&nbsp;��վ�Ƽ�ʹ��1024*768�����Ϸֱ��ʣ��Ƽ�ʹ��webkit���ĵ������";
    echo "</br>";
  ?><!---ʱ����ʾ���ֽ���---></span></div>
<div id="wb_Text3" style="position:absolute;left:10px;top:72px;width:263px;height:20px;z-index:5;text-align:left;">
<span style="color:#FFFFFF;font-family:����;font-size:16px;">Powered By <a href="http://www.ddpool.com">hehaoyuan1997</a></span></div>
<div id="wb_Text6" style="position:absolute;left:517px;top:70px;width:426px;height:18px;z-index:6;text-align:left;">
<span style="color:#FFFFFF;font-family:Arial;font-size:16px;"><!---copyright����---><?php echo "$copyright" ?><!---copyright���ֽ���---></span></div>
<div id="wb_Text1000" style="position:absolute;left:10px;top:3px;width:70px;height:17px;z-index:7;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><p>
    <a href="http://jigsaw.w3.org/css-validator/check/referer">
        <img style="border:0;width:88px;height:31px"
            src="http://jigsaw.w3.org/css-validator/images/vcss"
            alt="Valid CSS!" />
    </a>
</p></span></div>
</div>

<div id="Layer2" style="position:absolute;text-align:left;left:200px;top:70px;width:600px;height:282px;z-index:8;" title="">
<div id="wb_Text5" style="position:absolute;left:100px;top:20px;width:423px;height:152px;z-index:4;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>���ʴ�ͼ������ѵ�ô��&nbsp; </strong><br><br>�𣺴�ͼ����ȫ��ѡ�<br><br><strong>�����ҿ���ȥ�����ô�ͼ�����룿<br><br>�𣺿��Է���https://sourceforge.net/projects/hipoject/���Դ���롣</strong></span></div>
</div>
<div id="wb_CssMenu1" style="position:absolute;left:660px;top:0px;width:300px;height:40px;z-index:9;">
<ul>
<li class="firstmain"><a href="<?php echo "$websiteurl" ?>" target="_self">��ҳ</a>
</li>
<li><a href="<?php echo "".$websiteurl."about.php" ?>" target="_self">����</a>
</li>
<li><a href="<?php echo "".$websiteurl."help.php" ?>" target="_self">����</a>
</li>
</ul>
<br>
</div>
</div>
</body>
</html>