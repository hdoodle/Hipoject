<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<?php
include 'config.php';
?>
<title><?php echo "".$websitename.""?>&nbsp;-Powered By hehaoyuan1997</title>
<meta name="keywords" content="Hipoject,hehaoyuan1997">
<meta name="descrption" content="Hipoject��һ��ͼ������hehaoyuan1997��д">
<meta http-equiv="Content-Type" content="text/html; charset=GB2312" />
<meta name="author"
content="hehaoyuan1997">
<!---copyright (c) 2013-2013 hehaoyuan1997 All Rights Reserved--->
<!---Powered By hehaoyuan1997--->
<!---author website:http://www.ddpool.com/--->
<!---hehaoyuan1997��ʼ��2013��8��18��23:19:57��д--->
<style type="text/css">
div#container
{
   width: 960px;
   position: relative;
   margin-top: 0px;
   margin-left: auto;
   margin-right: auto;
   text-align: left;
}
body
{
   text-align: center;
   margin: 0;
   background-color: #E2E1E2;
   color: #000000;
}
</style>
<style type="text/css">
a
{
   color: #0000FF;
   text-decoration: underline;
}
a:visited
{
   color: #800080;
}
a:active
{
   color: #FF0000;
}
a:hover
{
   color: #0000FF;
   text-decoration: underline;
}
</style>
<style type="text/css">
#Layer2
{
   background-color: #D3D3D3;
}
#Layer1
{
   background-color: #2B7AFA;
}
#wb_Text1 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text1 div
{
   text-align: left;
}
#Layer3
{
   background-color: #2B7AFA;
}
#wb_Text4 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text4 div
{
   text-align: left;
}
#wb_Text3 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text3 div
{
   text-align: left;
}
#wb_Text6 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text6 div
{
   text-align: left;
}
#wb_Text2 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text2 div
{
   text-align: left;
}
#Table1
{
   border: 2px #000000 solid;
   background-color: transparent;
   border-spacing: 1px;
}
#Table1 td
{
   padding: 0px 0px 0px 0px;
}
#Table1 td div
{
   white-space: nowrap;
}
#wb_Text5 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text5 div
{
   text-align: left;
}
#wb_CssMenu1
{
   border: 0px #2B7AFA solid;
   background-color: transparent;
}
#wb_CssMenu1 ul
{
   list-style-type: none;
   margin: 0;
   padding: 0;
}
#wb_CssMenu1 li
{
   float: left;
   margin: 0;
   padding: 0px 0px 0px 0px;
   width: 100px;
}
#wb_CssMenu1 a
{
   display: block;
   float: left;
   color: #FFFFFF;
   border: 0px #C0C0C0 solid;
   background-color: #2B7AFA;
   background-image: none;
   font-family: "SimHei";
   font-size: 20px;
   font-weight: normal;
   font-style: normal;
   text-decoration: none;
   width: 90px;
   height: 40px;
   padding: 0px 5px 0px 5px;
   vertical-align: middle;
   line-height: 40px;
   text-align: center;
}
#wb_CssMenu1 li:hover a, #wb_CssMenu1 a:hover
{
   color: #2B7AFA;
   background-color: #FFFFFF;
   background-image: none;
   border: 0px #FFFFFF solid;
}
#wb_CssMenu1 li.firstmain
{
   padding-left: 0px;
}
#wb_CssMenu1 li.lastmain
{
   padding-right: 0px;
}
#wb_CssMenu1 br
{
   clear: both;
   font-size: 1px;
   height: 0;
   line-height: 0px;
}
#wb_Text1000 
{
   background-color: transparent;
   border: 0px #000000 solid;
   padding: 0;
   text-align: left;
}
#wb_Text1000 div
{
   text-align: left;
}
</style>
</head>
<body>
<div id="container">
<div id="Layer2" style="position:absolute;text-align:left;left:200px;top:70px;width:600px;height:282px;z-index:7;" title="">
<table style="position:absolute;left:97px;top:97px;width:281px;height:95px;z-index:0;" cellpadding="0" cellspacing="1" id="Table1">
<tr>
<th style="background-color:transparent;border:1px #C0C0C0 solid;text-align:left;vertical-align:top;width:114px;height:20px;"><div><span style="color:#000000;font-family:Arial;font-size:13px;">����</span></div>
</th>
<td style="background-color:transparent;border:1px #C0C0C0 solid;text-align:left;vertical-align:top;height:20px;"><div><span style="color:#000000;font-family:Arial;font-size:13px;"><?php echo "$websitename" ?></span></div>
</td>
</tr>
<tr>
<th style="background-color:transparent;border:1px #C0C0C0 solid;text-align:left;vertical-align:top;width:114px;height:20px;"><div><span style="color:#000000;font-family:Arial;font-size:13px;">�汾��</span></div>
</th>
<td style="background-color:transparent;border:1px #C0C0C0 solid;text-align:left;vertical-align:top;height:20px;"><div><span style="color:#000000;font-family:Arial;font-size:13px;"><?php echo "$version" ?></span></div>
</td>
</tr>
<tr>
<th style="background-color:transparent;border:1px #C0C0C0 solid;text-align:left;vertical-align:top;width:114px;height:18px;"><div><span style="color:#000000;font-family:Arial;font-size:13px;">build</span></div>
</th>
<td style="background-color:transparent;border:1px #C0C0C0 solid;text-align:left;vertical-align:top;height:18px;"><div><span style="color:#000000;font-family:Arial;font-size:13px;"><?php echo "$build" ?></span></div>
</td>
</tr>
<tr>
<th style="background-color:transparent;border:1px #C0C0C0 solid;text-align:left;vertical-align:top;width:114px;height:20px;"><div><span style="color:#000000;font-family:Arial;font-size:13px;">�˰汾��ʼд��</span></div>
</th>
<td style="background-color:transparent;border:1px #C0C0C0 solid;text-align:left;vertical-align:top;height:20px;"><div><span style="color:#000000;font-family:Arial;font-size:13px;"><?php echo "$date" ?></span></div>
</td>
</tr>
</table>
<div id="wb_Text5" style="position:absolute;left:100px;top:201px;width:371px;height:67px;z-index:1;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>&#29256;&#26435;&#20449;&#24687;</strong><br><br>&#27492;&#31243;&#24207;&#37096;&#20998;&#20351;&#29992;&#20102;&#20316;&#32773;leehui1983&#30340;&#20195;&#30721;&#65292;&#22312;&#27492;&#34920;&#31034;&#24863;&#35874;&#65292;&#22914;leehui1983&#19981;&#21516;&#24847;&#20351;&#29992;&#27492;&#20195;&#30721;&#35831;&#32852;&#31995;&#20316;&#32773;&#12290;</span></div>
<div id="wb_Text2" style="position:absolute;left:96px;top:6px;width:400px;height:84px;z-index:2;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><strong>&#20851;&#20110;Hipoject</strong><br><br>Hipoject&#35745;&#21010;&#26159;&#19968;&#20010;&#24320;&#28304;&#30340;&#22270;&#24202;&#20195;&#30721;&#65292;&#38754;&#21521;&#20110;&#36731;&#37327;&#32423;&#30340;&#22270;&#24202;&#26381;&#21153;&#65292;&#23545;&#20110;&#20195;&#30721;&#21830;&#29992;&#21270;&#30446;&#21069;&#26242;&#19981;&#38656;&#35201;&#20184;&#36153;&#12290;<br>&#32852;&#31995;&#20316;&#32773;&#65306;hehaoyuan1997@yeah.net </span></div>
</div>
<div id="Layer1" style="position:absolute;text-align:left;left:0px;top:0px;width:960px;height:40px;z-index:8;" title="">
<h1><div id="h1" style="position:absolute;left:10px;top:4px;width:316px;height:29px;z-index:0;text-align:left;font-weight��normal;"><span style="color:#FFFFFF;font-family:Arial;font-size:24px;"><?php echo "".$websitename."&nbsp".$version."" ?></span></div></h1>
</div>
<div id="Layer3" style="position:absolute;text-align:left;left:0px;top:400px;width:960px;height:100px;z-index:9;" title="">
<div id="wb_Text4" style="position:absolute;left:10px;top:50px;width:960px;height:20px;z-index:4;text-align:left;">
<span style="color:#FFFFFF;font-family:����;font-size:16px;"><!---ʱ����ʾ����---><?php
    echo date("������Y��m��d��Hʱi��s��(��ʱ��ʱ��ΪeP)");
    echo "&nbsp;��վ�Ƽ�ʹ��1024*768�����Ϸֱ��ʣ��Ƽ�ʹ��webkit���ĵ������";
    echo "</br>";
  ?><!---ʱ����ʾ���ֽ���---></span></div>
<div id="wb_Text3" style="position:absolute;left:10px;top:72px;width:263px;height:20px;z-index:5;text-align:left;">
<span style="color:#FFFFFF;font-family:����;font-size:16px;">Powered By <a href="http://www.ddpool.com">hehaoyuan1997</a></span></div>
<div id="wb_Text6" style="position:absolute;left:517px;top:70px;width:426px;height:18px;z-index:6;text-align:left;">
<span style="color:#FFFFFF;font-family:Arial;font-size:16px;"><!---copyright����---><?php echo "$copyright" ?><!---copyright���ֽ���---></span></div>
<div id="wb_Text1000" style="position:absolute;left:10px;top:3px;width:70px;height:17px;z-index:7;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:13px;"><p>
    <a href="http://jigsaw.w3.org/css-validator/check/referer">
        <img style="border:0;width:88px;height:31px"
            src="http://jigsaw.w3.org/css-validator/images/vcss"
            alt="Valid CSS!" />
    </a>
</p></span></div>
</div>
<div id="wb_CssMenu1" style="position:absolute;left:660px;top:0px;width:300px;height:40px;z-index:10;">
<ul>
<li class="firstmain"><a href="<?php echo "$websiteurl" ?>" target="_self">��ҳ</a>
</li>
<li><a href="<?php echo "".$websiteurl."about.php" ?>" target="_self">����</a>
</li>
<li><a href="<?php echo "".$websiteurl."help.php" ?>" target="_self">����</a>
</li>
</ul>
<br>
</div>

</div>
</body>
</html>